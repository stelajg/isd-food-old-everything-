package com.isdfood.isdproject.repositories;

import com.isdfood.isdproject.model.Notification;
import org.springframework.data.repository.CrudRepository;

public interface NotificationRepository extends CrudRepository<Notification,Long> {
}
