package com.isdfood.isdproject.repositories;

import com.isdfood.isdproject.model.Menu;
import org.springframework.data.repository.CrudRepository;

public interface MenuRepository extends CrudRepository<Menu,Long> {
}
