package com.isdfood.isdproject.exceptions;

public class IdenticalPasswordException extends Exception{
}
