package com.isdinternship.isdfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsdFoodApplicationTests {

    @Test
    void contextLoads() {
    }

}
