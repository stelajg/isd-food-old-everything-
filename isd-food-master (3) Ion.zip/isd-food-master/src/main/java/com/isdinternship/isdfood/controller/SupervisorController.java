package com.isdinternship.isdfood.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("supervisor/users")
public class SupervisorController {
}
