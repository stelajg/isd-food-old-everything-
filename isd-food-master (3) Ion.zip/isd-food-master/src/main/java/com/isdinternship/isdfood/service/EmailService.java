package com.isdinternship.isdfood.service;

public interface EmailService {
    void sendEmail(String email, String text);
}
