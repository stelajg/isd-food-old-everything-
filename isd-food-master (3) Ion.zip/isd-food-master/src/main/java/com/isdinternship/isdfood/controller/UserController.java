package com.isdinternship.isdfood.controller;

import com.isdinternship.isdfood.model.User;
import com.isdinternship.isdfood.service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @PostMapping
    public ResponseEntity<User> save(@RequestBody @Valid User user, BindingResult bindingResult) {

        if (!userService.existsByEmail(user.getEmail()))
            return new ResponseEntity<>(userService.save(user), HttpStatus.CREATED);

        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }

    @GetMapping
    public ResponseEntity<List<User>> getAll() {
        return new ResponseEntity<>(userService.getAll(), HttpStatus.OK);
    }
}
