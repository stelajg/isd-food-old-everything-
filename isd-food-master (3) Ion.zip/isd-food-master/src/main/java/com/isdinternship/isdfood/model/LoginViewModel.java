package com.isdinternship.isdfood.model;

import lombok.Data;

@Data
public class LoginViewModel {

    private String email;
    private String password;

}
