package com.isdinternship.isdfood.service.impl;

import com.isdinternship.isdfood.model.User;
import com.isdinternship.isdfood.repository.UserRepository;
import com.isdinternship.isdfood.service.EmailService;
import com.isdinternship.isdfood.service.UserService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    private final EmailService emailService;

    @Override
    public User save(User user) {
        String password = this.generatePassword();

        try {
            emailService.sendEmail(user.getEmail(), "Your password: " + password);

        } catch (Exception e) {
            e.printStackTrace();
        }

        user.setPassword(passwordEncoder.encode(password));

        return userRepository.save(user);
    }

    @Override
    public List<User> getAll() {
        return userRepository.findAll();
    }

    @Override
    public boolean existsByEmail(String email) {
        return userRepository.findByEmail(email) != null;
    }

    private String generatePassword() {
        int length = 10;
        boolean useLetters = true;
        boolean useNumbers = true;
        String generatedPassword = RandomStringUtils.random(length, useLetters, useNumbers);

        return generatedPassword;
    }
}
