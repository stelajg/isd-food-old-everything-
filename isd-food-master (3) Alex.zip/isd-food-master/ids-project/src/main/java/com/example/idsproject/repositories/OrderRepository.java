package com.example.idsproject.repositories;

public class OrderRepository {
}
