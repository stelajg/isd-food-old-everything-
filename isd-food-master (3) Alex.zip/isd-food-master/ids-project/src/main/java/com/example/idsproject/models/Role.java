package com.example.idsproject.models;

public enum Role {
    USER, ADMINISTRATOR, SUPERVISOR
}
