package com.example.idsproject.repositories;

public class UserRepository {
}
