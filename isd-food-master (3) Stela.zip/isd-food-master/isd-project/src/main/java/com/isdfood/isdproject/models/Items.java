package com.isdfood.isdproject.models;

public class Items {
    private final String name;

    public Items(String name) {
        this.name = name;
    }
}
