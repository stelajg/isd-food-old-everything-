package com.isdfood.isdproject.api;

import com.isdfood.isdproject.service.ItemService;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ItemController {
    private ItemService itemService;


}
