package com.isdfood.isdproject.models;

public enum Role {
    User, Supervisor, Administrator
}
