package com.isdfood.isdproject.model.enums;

public enum Role {
    USER,ADMIN
}
